from a2_support import *

# Write your classes here

def main():
    # uncomment the lines below once you've written your Sokoban class
    # game = Sokoban('maze_files/maze1.txt')
    # game.play_game()
    pass

if __name__ == '__main__':
    main()
