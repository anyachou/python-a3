import tkinter as tk
from tkinter import messagebox, filedialog
from typing import Callable
from model import SokobanModel, Tile, Entity
from a2_support import *
from a3_support import *

# Write your classes and functions here


def main() -> None:
    """ The main function. """
    pass  # Write your main code here


if __name__ == "__main__":
    main()
